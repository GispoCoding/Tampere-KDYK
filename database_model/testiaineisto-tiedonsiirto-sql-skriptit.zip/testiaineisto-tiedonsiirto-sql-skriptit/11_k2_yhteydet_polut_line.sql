/*
 Kopioidaan yk049_testiaineisto.k2_yhteydet_polut_line-taulusta tiedot kaavaobjekti- ja kaavamaarays-
 sekä yhdistetään kaavaobjektit siihen liittyvään kaavamäärykseen ja k2-teemaan
*/
WITH k2_yhteydet_polut_line_select AS (
	SELECT
		*,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavaobjekti_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavamaarays_uusi
	FROM
		yk049_testiaineisto.k2_yhteydet_polut_line
),
kaavaobjekti_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavaobjekti_viiva(id, geom, kayttotarkoitus_nimi, pituus_km, alkup_taulun_nimi, id_yleiskaava)
	SELECT
		k2_yhteydet_polut_line_select.id_kaavaobjekti_uusi,
		ST_SetSRID(ST_Force3DZ(k2_yhteydet_polut_line_select.geom), 3878),
		k2_yhteydet_polut_line_select."Kaavamaarays_otsikko",
		k2_yhteydet_polut_line_select.pituus_km,
		'k2_yhteydet_polut_line',
		yleiskaava.id
	FROM
		k2_yhteydet_polut_line_select,
		yk_yleiskaava.yleiskaava
	WHERE
		yleiskaava.nro = 'yk049'
	RETURNING id
),
kaavamaarays_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavamaarays(id, maaraysteksti, linkki)
	SELECT
		k2_yhteydet_polut_line_select.id_kaavamaarays_uusi,
		k2_yhteydet_polut_line_select."Kaavamaarays_teksti",
		k2_yhteydet_polut_line_select.kaavamaarays
	FROM
		k2_yhteydet_polut_line_select
	RETURNING id
),
kaavaobjekti_teema_yhteys_insert AS (
	INSERT INTO
		yk_kuvaustekniikka.kaavaobjekti_teema_yhteys(id, id_kaavaobjekti_viiva, id_teema)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		teema.id
	FROM
		k2_yhteydet_polut_line_select,
		kaavaobjekti_insert,
		yk_kuvaustekniikka.teema
	WHERE
		k2_yhteydet_polut_line_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		teema.nimi = 'yk049_k2'
)
INSERT INTO
	yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys(id, id_kaavaobjekti_viiva, id_kaavamaarays)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	kaavaobjekti_insert.id,
	kaavamaarays_insert.id
FROM
	k2_yhteydet_polut_line_select,
	kaavaobjekti_insert,
	kaavamaarays_insert
WHERE
	k2_yhteydet_polut_line_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
	k2_yhteydet_polut_line_select.id_kaavamaarays_uusi = kaavamaarays_insert.id;
	
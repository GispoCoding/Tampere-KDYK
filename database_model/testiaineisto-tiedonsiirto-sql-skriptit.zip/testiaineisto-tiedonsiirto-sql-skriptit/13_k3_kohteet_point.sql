
-- DELETE FROM yk_yleiskaava.kaavaobjekti;
-- DELETE FROM yk_yleiskaava.kaavamaarays;
-- DELETE FROM yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys;
-- DELETE FROM yk_mitoitus_varanto.mitoitus;
-- DELETE FROM yk_kuvaustekniikka.kaavaobjekti_teema_yhteys;

/*
 Kopioidaan yk049_testiaineisto.k3_kohteet_point-taulusta tiedot kaavaobjekti-, kaavamaarays-
 ja lahtoaineisto-tauluihin sekä yhdistetään kaavaobjektit siihen liittyvään kaavamäärykseen ja k3-teemaan
*/
WITH k3_kohteet_point_select AS (
	SELECT
		*,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavaobjekti_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavamaarays_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_lahtoaineisto_uusi
	FROM
		yk049_testiaineisto.k3_kohteet_point
),
kaavaobjekti_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavaobjekti_piste(id, geom, kayttotarkoitus_nimi, nimi, karttamerkinta, mj_kp_laji, mj_kp_tyyppi, mj_kp_tyypintarkenne, mj_kp_ajoitus, mj_kp_tunnus, alkup_taulun_nimi, id_yleiskaava)
	SELECT
		k3_kohteet_point_select.id_kaavaobjekti_uusi,
		ST_SetSRID(ST_Force3DZ(k3_kohteet_point_select.geom), 3878),
		k3_kohteet_point_select."Kaavamaarays_otsikko",
		k3_kohteet_point_select.kohteen_nimi,
		k3_kohteet_point_select.karttamerkinta,
		k3_kohteet_point_select.laji,
		k3_kohteet_point_select.mj_tyyppi,
		k3_kohteet_point_select.mj_tyypintarkenne,
		k3_kohteet_point_select.ajoitus,
		k3_kohteet_point_select.mj_tunnus,
		'k3_kohteet_point',
		yleiskaava.id
	FROM
		k3_kohteet_point_select,
		yk_yleiskaava.yleiskaava
	WHERE
		yleiskaava.nro = 'yk049'
	RETURNING id
),
kaavamaarays_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavamaarays(id, maaraysteksti, linkki)
	SELECT
		k3_kohteet_point_select.id_kaavamaarays_uusi,
		k3_kohteet_point_select."Kaavamaarays_teksti",
		k3_kohteet_point_select.kaavamaarays
	FROM
		k3_kohteet_point_select
	RETURNING id
),
lahtoaineisto_insert AS (
	INSERT INTO
		yk_prosessi.lahtoaineisto(id, linkitys_tyyppi, linkki_data)
	SELECT
		k3_kohteet_point_select.id_lahtoaineisto_uusi,
		'tre_siiri',
		k3_kohteet_point_select.linkki
	FROM
		k3_kohteet_point_select
	RETURNING id
),
lahtoaineisto_yleiskaava_yhteys_insert AS (
	INSERT INTO
		yk_prosessi.lahtoaineisto_yleiskaava_yhteys(id, id_kaavaobjekti_piste, id_lahtoaineisto)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		lahtoaineisto_insert.id
	FROM
		k3_kohteet_point_select,
		kaavaobjekti_insert,
		lahtoaineisto_insert
	WHERE
		k3_kohteet_point_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		k3_kohteet_point_select.id_lahtoaineisto_uusi = lahtoaineisto_insert.id
),
kaavaobjekti_teema_yhteys_insert AS (
	INSERT INTO
		yk_kuvaustekniikka.kaavaobjekti_teema_yhteys(id, id_kaavaobjekti_piste, id_teema)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		teema.id
	FROM
		k3_kohteet_point_select,
		kaavaobjekti_insert,
		yk_kuvaustekniikka.teema
	WHERE
		k3_kohteet_point_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		teema.nimi = 'yk049_k3'
)
INSERT INTO
	yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys(id, id_kaavaobjekti_piste, id_kaavamaarays)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	kaavaobjekti_insert.id,
	kaavamaarays_insert.id
FROM
	k3_kohteet_point_select,
	kaavaobjekti_insert,
	kaavamaarays_insert
WHERE
	k3_kohteet_point_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
	k3_kohteet_point_select.id_kaavamaarays_uusi = kaavamaarays_insert.id;
	
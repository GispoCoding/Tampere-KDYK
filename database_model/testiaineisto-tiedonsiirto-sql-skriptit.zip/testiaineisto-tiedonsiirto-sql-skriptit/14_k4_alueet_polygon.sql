
-- DELETE FROM yk_yleiskaava.kaavaobjekti;
-- DELETE FROM yk_yleiskaava.kaavamaarays;
-- DELETE FROM yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys;
-- DELETE FROM yk_mitoitus_varanto.mitoitus;
-- DELETE FROM yk_kuvaustekniikka.kaavaobjekti_teema_yhteys;

/*
 Kopioidaan yk049_testiaineisto.k4_alueet_polygon-taulusta tiedot kaavaobjekti-, kaavamaarays-
 ja mitoitustauluihin sekä yhdistetään kaavaobjektit siihen liittyvään kaavamäärykseen ja k4-teemaan
*/
WITH k4_alueet_polygon_select AS (
	SELECT
		*,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavaobjekti_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavamaarays_uusi
	FROM
		yk049_testiaineisto.k4_alueet_polygon
),
kaavaobjekti_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavaobjekti_alue(id, geom, kayttotarkoitus_nimi, nimi, karttamerkinta, alkup_taulun_nimi, id_yleiskaava)
	SELECT
		k4_alueet_polygon_select.id_kaavaobjekti_uusi,
		ST_SetSRID(ST_Force3DZ(k4_alueet_polygon_select.geom), 3878),
		k4_alueet_polygon_select."Kaavamaarays_otsikko",
		k4_alueet_polygon_select.alue_nimi,
		k4_alueet_polygon_select.karttamerkinta,
		'k4_alueet_polygon',
		yleiskaava.id
	FROM
		k4_alueet_polygon_select,
		yk_yleiskaava.yleiskaava
	WHERE
		yleiskaava.nro = 'yk049'
	RETURNING id
),
kaavamaarays_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavamaarays(id, maaraysteksti, linkki)
	SELECT
		k4_alueet_polygon_select.id_kaavamaarays_uusi,
		k4_alueet_polygon_select."Kaavamaarays_teksti",
		k4_alueet_polygon_select.kaavamaarays
	FROM
		k4_alueet_polygon_select
	RETURNING id
),
mitoitus_insert AS (
	INSERT INTO
		yk_mitoitus_varanto.mitoitus(id, pinta_ala, id_kaavaobjekti_alue)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		k4_alueet_polygon_select.pinta_ala_m2,
		kaavaobjekti_insert.id
	FROM
		k4_alueet_polygon_select,
		kaavaobjekti_insert
	WHERE
		k4_alueet_polygon_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id
),
kaavaobjekti_teema_yhteys_insert AS (
	INSERT INTO
		yk_kuvaustekniikka.kaavaobjekti_teema_yhteys(id, id_kaavaobjekti_alue, id_teema)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		teema.id
	FROM
		k4_alueet_polygon_select,
		kaavaobjekti_insert,
		yk_kuvaustekniikka.teema
	WHERE
		k4_alueet_polygon_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		teema.nimi = 'yk049_k4'
)
INSERT INTO
	yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys(id, id_kaavaobjekti_alue, id_kaavamaarays)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	kaavaobjekti_insert.id,
	kaavamaarays_insert.id
FROM
	k4_alueet_polygon_select,
	kaavaobjekti_insert,
	kaavamaarays_insert
WHERE
	k4_alueet_polygon_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
	k4_alueet_polygon_select.id_kaavamaarays_uusi = kaavamaarays_insert.id;
	
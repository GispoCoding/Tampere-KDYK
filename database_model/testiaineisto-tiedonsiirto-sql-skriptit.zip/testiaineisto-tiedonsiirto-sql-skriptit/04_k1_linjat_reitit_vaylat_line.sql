/*
 Kopioidaan yk049_testiaineisto.k1_linjat_reitit_vaylat_line-taulusta tiedot kaavaobjekti- ja kaavamaarays-
 sekä yhdistetään kaavaobjektit siihen liittyvään kaavamäärykseen ja k1-teemaan
*/
WITH k1_linjat_reitit_vaylat_line_select AS (
	SELECT
		*,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavaobjekti_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavamaarays_uusi
	FROM
		yk049_testiaineisto.k1_linjat_reitit_vaylat_line
),
kaavaobjekti_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavaobjekti_viiva(id, geom, kayttotarkoitus_nimi, alkup_taulun_nimi, id_yleiskaava)
	SELECT
		k1_linjat_reitit_vaylat_line_select.id_kaavaobjekti_uusi,
		ST_SetSRID(ST_Force3DZ(k1_linjat_reitit_vaylat_line_select.geom), 3878),
		k1_linjat_reitit_vaylat_line_select."Kaavamaarays_otsikko",
		'k1_linjat_reitit_vaylat_line',
		yleiskaava.id
	FROM
		k1_linjat_reitit_vaylat_line_select,
		yk_yleiskaava.yleiskaava
	WHERE
		yleiskaava.nro = 'yk049'
	RETURNING id
),
kaavamaarays_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavamaarays(id, maaraysteksti, linkki)
	SELECT
		k1_linjat_reitit_vaylat_line_select.id_kaavamaarays_uusi,
		k1_linjat_reitit_vaylat_line_select."Kaavamaarays_teksti",
		k1_linjat_reitit_vaylat_line_select.kaavamaarays
	FROM
		k1_linjat_reitit_vaylat_line_select
	RETURNING id
),
kaavaobjekti_teema_yhteys_insert AS (
	INSERT INTO
		yk_kuvaustekniikka.kaavaobjekti_teema_yhteys(id, id_kaavaobjekti_viiva, id_teema)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		teema.id
	FROM
		k1_linjat_reitit_vaylat_line_select,
		kaavaobjekti_insert,
		yk_kuvaustekniikka.teema
	WHERE
		k1_linjat_reitit_vaylat_line_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		teema.nimi = 'yk049_k1'
)
INSERT INTO
	yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys(id, id_kaavaobjekti_viiva, id_kaavamaarays)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	kaavaobjekti_insert.id,
	kaavamaarays_insert.id
FROM
	k1_linjat_reitit_vaylat_line_select,
	kaavaobjekti_insert,
	kaavamaarays_insert
WHERE
	k1_linjat_reitit_vaylat_line_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
	k1_linjat_reitit_vaylat_line_select.id_kaavamaarays_uusi = kaavamaarays_insert.id;
	

/*
 Luodaan yleiskaavan INSPIRE-kaavatasoa vastaava koodiluokan rivi,
 joka vastaa Tampereen kaupungin yleiskaavan tasoja. 
*/
INSERT INTO
	yk_koodiluettelot.kaavan_taso(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'paikallinen',
	'Kaava, joka kattaa vain osan kunnasta.'
);

/*
 Luodaan yk_koodiluettelot.prosessin_vaihe-taulun rivit
*/
INSERT INTO
	yk_koodiluettelot.prosessin_vaihe(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'ehdotus',
	'Kaava tai yksittäinen kaavakohde on virallisesti hyväksyttävänä tai vahvistettavana.'
);
INSERT INTO
	yk_koodiluettelot.prosessin_vaihe(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'kumottu',
	'Kaava tai yksittäinen kaavakohde on korvattu toisella kaavalla tai se ei enää ole voimassa.'
);
INSERT INTO
	yk_koodiluettelot.prosessin_vaihe(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'laillisesti_sitova_tai_voimassa',
	'Kaava tai yksittäinen kaavakohde on hyväksytty tai vahvistettu ja se on laillisesti sitova tai voimassa.'
);
INSERT INTO
	yk_koodiluettelot.prosessin_vaihe(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'luonnos',
	'Kaava tai yksittäinen kaavakohde on laadittavana.'
);

/*
 Luodaan yk_koodiluettelot.laillinen_sitovuus-taulun rivit
*/
INSERT INTO
	yk_koodiluettelot.laillinen_sitovuus(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'ei_sitova',
	'Kaavamääräys ei ole sitova.'
);
INSERT INTO
	yk_koodiluettelot.laillinen_sitovuus(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'maaritelty_lainsaadannossa',
	'Kaavamääräys on määritelty lainsäädännössä.'
);
INSERT INTO
	yk_koodiluettelot.laillinen_sitovuus(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'sitova_ainoastaan_viranomaisille',
	'Kaavamääräys on sitova ainoastaan tietyille viranomaisille.'
);
INSERT INTO
	yk_koodiluettelot.laillinen_sitovuus(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'sitova_kehittajille',
	'Kaavamääräys on sitova ainoastaan alueen kehittämisestä vastaavalle taholle.'
);
INSERT INTO
	yk_koodiluettelot.laillinen_sitovuus(id, koodi, kuvaus)
VALUES(
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'yleisesti_sitova',
	'Kaavamääräys sitoo kaikkia.'
);

/*
 Luodaan 'Keskustan strateginen osayleiskaava' yleiskaava-rivi
*/
INSERT INTO
	yk_yleiskaava.yleiskaava(id, nimi, kaavan_ulkorajaus, nro, id_kaavan_taso)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'Keskustan strateginen osayleiskaava',
	ST_SetSRID(ST_Force3DZ(geom), 3878),
	'yk048',
	kaavan_taso.id
FROM
	yk049_testiaineisto.k1_erityisominaisuus_polygon,
	yk_koodiluettelot.kaavan_taso
WHERE
	k1_erityisominaisuus_polygon."Yleiskaavan_numero"='YK049' AND
	kaavan_taso.koodi = 'paikallinen';

/*
 Luodaan 'Kantakaupungin yleiskaava 2017-2021' yleiskaava-rivi
*/
INSERT INTO
	yk_yleiskaava.yleiskaava(id, nimi, kaavan_ulkorajaus, nro, id_kaavan_taso)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	'Kantakaupungin yleiskaava 2017-2021',
	ST_SetSRID(ST_Force3DZ(geom), 3878),
	'yk049',
	kaavan_taso.id
FROM
	yk049_testiaineisto.yk2040_kaava_alue_polygon,
	yk_koodiluettelot.kaavan_taso
WHERE
	kaavan_taso.koodi = 'paikallinen';

/*
 Lisätään teemat 
*/
INSERT INTO
	yk_kuvaustekniikka.teema(id, nimi, id_yleiskaava)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	 'yk049_k1',
	 id
FROM
	yk_yleiskaava.yleiskaava
WHERE
	nro='yk049';
	
INSERT INTO
	yk_kuvaustekniikka.teema(id, nimi, id_yleiskaava)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	 'yk049_k2',
	 id
FROM
	yk_yleiskaava.yleiskaava
WHERE
	nro='yk049';
	
INSERT INTO
	yk_kuvaustekniikka.teema(id, nimi, id_yleiskaava)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	 'yk049_k3',
	 id
FROM
	yk_yleiskaava.yleiskaava
WHERE
	nro='yk049';
	
INSERT INTO
	yk_kuvaustekniikka.teema(id, nimi, id_yleiskaava)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	 'yk049_k4',
	 id
FROM
	yk_yleiskaava.yleiskaava
WHERE
	nro='yk049';

/*
 Kopioidaan 'Kantakaupungin yleiskaava 2017-2021'-yleiskaavan yleismääräykset yleismaarays-tauluun
 ja yhdistetään vastaava k1-k4-teema yleismääräykseen
*/
WITH yleismaarays_insert AS (
	INSERT INTO 
		yk_yleiskaava.yleismaarays(id, linkki, id_yleiskaava)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavamaarays,
		yk.id
	FROM
		yk_yleiskaava.yleiskaava as yk,
		yk049_testiaineisto.yk2040_kaava_alue_polygon
	WHERE
		yk.nro='yk049'
	returning id
)
INSERT INTO
	yk_kuvaustekniikka.yleismaarays_teema_yhteys(id, id_yleismaarays, id_teema)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	yleismaarays_insert.id,
	teema.id
FROM
	yleismaarays_insert,
	yk_kuvaustekniikka.teema
WHERE
	teema.nimi='yk049_k1';
	
WITH yleismaarays_insert AS (
	INSERT INTO 
		yk_yleiskaava.yleismaarays(id, linkki, id_yleiskaava)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavamaarays_2,
		yk.id
	FROM
		yk_yleiskaava.yleiskaava as yk,
		yk049_testiaineisto.yk2040_kaava_alue_polygon
	WHERE
		yk.nro='yk049'
	returning id
)
INSERT INTO
	yk_kuvaustekniikka.yleismaarays_teema_yhteys(id, id_yleismaarays, id_teema)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	yleismaarays_insert.id,
	teema.id
FROM
	yleismaarays_insert,
	yk_kuvaustekniikka.teema
WHERE
	teema.nimi='yk049_k2';
	
WITH yleismaarays_insert AS (
	INSERT INTO 
		yk_yleiskaava.yleismaarays(id, linkki, id_yleiskaava)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavamaarays_3,
		yk.id
	FROM
		yk_yleiskaava.yleiskaava as yk,
		yk049_testiaineisto.yk2040_kaava_alue_polygon
	WHERE
		yk.nro='yk049'
	returning id
)
INSERT INTO
	yk_kuvaustekniikka.yleismaarays_teema_yhteys(id, id_yleismaarays, id_teema)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	yleismaarays_insert.id,
	teema.id
FROM
	yleismaarays_insert,
	yk_kuvaustekniikka.teema
WHERE
	teema.nimi='yk049_k3';
	
WITH yleismaarays_insert AS (
	INSERT INTO 
		yk_yleiskaava.yleismaarays(id, linkki, id_yleiskaava)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavamaarays_4,
		yk.id
	FROM
		yk_yleiskaava.yleiskaava as yk,
		yk049_testiaineisto.yk2040_kaava_alue_polygon
	WHERE
		yk.nro='yk049'
	returning id
)
INSERT INTO
	yk_kuvaustekniikka.yleismaarays_teema_yhteys(id, id_yleismaarays, id_teema)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	yleismaarays_insert.id,
	teema.id
FROM
	yleismaarays_insert,
	yk_kuvaustekniikka.teema
WHERE
	teema.nimi='yk049_k4';
	
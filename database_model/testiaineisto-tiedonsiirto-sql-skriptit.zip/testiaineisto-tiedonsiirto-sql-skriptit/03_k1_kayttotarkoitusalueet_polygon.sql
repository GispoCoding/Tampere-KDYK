
-- DELETE FROM yk_yleiskaava.kaavaobjekti;
-- DELETE FROM yk_yleiskaava.kaavamaarays;
-- DELETE FROM yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys;
-- DELETE FROM yk_mitoitus_varanto.mitoitus;
-- DELETE FROM yk_kuvaustekniikka.kaavaobjekti_teema_yhteys;

/*
 Kopioidaan yk049_testiaineisto.k1_kayttotarkoitusalueet-taulusta tiedot kaavaobjekti-, kaavamaarays-
 ja mitoitustauluihin sekä yhdistetään kaavaobjektit siihen liittyvään kaavamäärykseen ja k1-teemaan
*/
WITH k1_kayttotarkoitusalueet_select AS (
	SELECT
		*,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavaobjekti_uusi,
		(md5(random()::text || clock_timestamp()::text)::uuid) AS id_kaavamaarays_uusi
	FROM
		yk049_testiaineisto.k1_kayttotarkoitusalueet
),
kaavaobjekti_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavaobjekti_alue(id, geom, kayttotarkoitus_koodi, kayttotarkoitus_nimi, nimi, nro, yhdrak_palvelualue, yhdrak_rakennusoikeus, lisatieto, alkup_taulun_nimi, id_yleiskaava)
	SELECT
		k1_kayttotarkoitusalueet_select.id_kaavaobjekti_uusi,
		ST_SetSRID(ST_Force3DZ(k1_kayttotarkoitusalueet_select.geom), 3878),
		k1_kayttotarkoitusalueet_select."Kayttotarkoitus",
		k1_kayttotarkoitusalueet_select."Kaavamaarays_otsikko",
		k1_kayttotarkoitusalueet_select.alue_nimi,
		k1_kayttotarkoitusalueet_select.alue_numero,
		k1_kayttotarkoitusalueet_select.palvelualue,
		k1_kayttotarkoitusalueet_select.rakennusoikeus,
		k1_kayttotarkoitusalueet_select.selite,
		'k1_kayttotarkoitusalueet',
		yleiskaava.id
	FROM
		k1_kayttotarkoitusalueet_select,
		yk_yleiskaava.yleiskaava
	WHERE
		yleiskaava.nro = 'yk049'
	RETURNING id
),
kaavamaarays_insert AS (
	INSERT INTO
		yk_yleiskaava.kaavamaarays(id, maaraysteksti, linkki)
	SELECT
		k1_kayttotarkoitusalueet_select.id_kaavamaarays_uusi,
		k1_kayttotarkoitusalueet_select."Kaavamaarays_teksti",
		k1_kayttotarkoitusalueet_select.kaavamaarays
	FROM
		k1_kayttotarkoitusalueet_select
	RETURNING id
),
mitoitus_insert AS (
	INSERT INTO
		yk_mitoitus_varanto.mitoitus(id, pinta_ala, id_kaavaobjekti_alue)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		k1_kayttotarkoitusalueet_select.pinta_ala_m2,
		kaavaobjekti_insert.id
	FROM
		k1_kayttotarkoitusalueet_select,
		kaavaobjekti_insert
	WHERE
		k1_kayttotarkoitusalueet_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id
),
kaavaobjekti_teema_yhteys_insert AS (
	INSERT INTO
		yk_kuvaustekniikka.kaavaobjekti_teema_yhteys(id, id_kaavaobjekti_alue, id_teema)
	SELECT
		(md5(random()::text || clock_timestamp()::text)::uuid),
		kaavaobjekti_insert.id,
		teema.id
	FROM
		k1_kayttotarkoitusalueet_select,
		kaavaobjekti_insert,
		yk_kuvaustekniikka.teema
	WHERE
		k1_kayttotarkoitusalueet_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
		teema.nimi = 'yk049_k1'
)
INSERT INTO
	yk_yleiskaava.kaavaobjekti_kaavamaarays_yhteys(id, id_kaavaobjekti_alue, id_kaavamaarays)
SELECT
	(md5(random()::text || clock_timestamp()::text)::uuid),
	kaavaobjekti_insert.id,
	kaavamaarays_insert.id
FROM
	k1_kayttotarkoitusalueet_select,
	kaavaobjekti_insert,
	kaavamaarays_insert
WHERE
	k1_kayttotarkoitusalueet_select.id_kaavaobjekti_uusi = kaavaobjekti_insert.id AND
	k1_kayttotarkoitusalueet_select.id_kaavamaarays_uusi = kaavamaarays_insert.id;
	